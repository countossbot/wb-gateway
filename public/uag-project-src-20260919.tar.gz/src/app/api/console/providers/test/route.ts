// POST /api/console/providers/test —— 提供商探活（保存前实测 + 卡片级测试按钮）。
// 恢复自 v3.0.9 Task 16（工作区快照缺失该文件，按 worklog 规格重建）。
//
// 载荷 A { providerId }          ：DB 读 Provider + Account（与 dbToConfigRaw 同构组装）→ 只读探活。
// 载荷 B { type, config, credentials }：草稿实测（表单值；workbuddy 凭据包成 __draft__ 临时账号，
//                                   id 不命中 DB → getActiveToken 纯用传入 accessToken，不落库不轮换）。
//
// 按类型探活策略：
// - workbuddy ：getBalance() billing 只读验证（12s 超时兜底）
// - openai    ：GET {baseUrl}/models（Bearer）
// - anthropic ：GET {baseUrl}/models（x-api-key + anthropic-version）
// - opencode  ：GET {baseUrl}/models（CLI UA 公开接口）
// - qwenweb   ：凭据具备性校验（反爬链不做半吊子探活，明示需真实调用验证）
//
// 网络失败结构化返回（success:false + 超时/不可达提示），绝不 500。
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSessionOr401, ok } from "@/lib/gateway/console/consoleHelpers";
import { fetchWithProxy } from "@/lib/gateway/proxy/proxyAgent";
import { WorkBuddyProvider } from "@/lib/gateway/providers/workbuddy";

export const dynamic = "force-dynamic";

const TEST_TIMEOUT_MS = 12_000;

export interface ProviderTestResult {
  success: boolean;
  elapsedMs: number;
  message: string;
  balance?: number;
  total?: number;
  modelsCount?: number;
  models?: string[];
  region?: string;
  hasCredentials?: boolean;
  error?: string;
}

function networkErrorMessage(e: unknown): string {
  const raw = e instanceof Error ? e.message : String(e);
  if (e instanceof Error && e.name === "TimeoutError") return `超时（${TEST_TIMEOUT_MS / 1000}s）· 上游不可达或网络受限`;
  if (/ECONNREFUSED|ENOTFOUND|EAI_AGAIN|fetch failed|network/i.test(raw)) return `网络不可达 · ${raw.slice(0, 120)}`;
  return raw.slice(0, 300);
}

// 从 DB 组装 workbuddy 引擎形态 config（与 dbToConfigRaw 的 providers 分支同构）
async function buildWorkbuddyConfig(providerId: string): Promise<Record<string, unknown> | null> {
  const provider = await db.provider.findUnique({ where: { id: providerId } });
  if (!provider || provider.type !== "workbuddy") return null;
  const accounts = await db.account.findMany({
    where: { providerId },
    orderBy: { createdAt: "asc" },
  });
  return {
    ...((provider.config as Record<string, unknown>) || {}),
    accounts: accounts
      .filter((a) => a.enabled)
      .map((a) => ({
        id: a.id,
        name: a.name,
        enabled: a.enabled,
        ...((a.credentials as Record<string, unknown>) || {}),
      })),
  };
}

async function testWorkbuddy(
  providerId: string,
  cfg: Record<string, unknown>,
  proxyOverride: string | null
): Promise<ProviderTestResult> {
  const started = Date.now();
  const provider = new WorkBuddyProvider({
    id: providerId,
    name: (cfg.name as string) || providerId,
    type: "workbuddy",
    enabled: true,
    config: cfg,
  } as unknown as ConstructorParameters<typeof WorkBuddyProvider>[0]);
  try {
    const balance = await Promise.race([
      provider.getBalance(),
      new Promise<null>((resolve) => setTimeout(() => resolve(null), TEST_TIMEOUT_MS)),
    ]);
    const elapsedMs = Date.now() - started;
    if (!balance) {
      return { success: false, elapsedMs, message: `billing 探活超时（${TEST_TIMEOUT_MS / 1000}s）`, error: "timeout" };
    }
    const accountsCount = Array.isArray(cfg.accounts) ? cfg.accounts.length : 0;
    const balanceNum = typeof balance.balance === "number" ? balance.balance : parseFloat(String(balance.balance ?? "")) || 0;
    const totalNum = typeof balance.total === "number" ? balance.total : parseFloat(String(balance.total ?? "")) || 0;
    if (balance.success) {
      return {
        success: true,
        elapsedMs,
        message: `billing 接口连通 · ${accountsCount} 账号 · 余额 ${balanceNum}/${totalNum} ${balance.unit || "积分"}`,
        balance: balanceNum,
        total: totalNum,
        region: (cfg.region as string) || "cn",
        hasCredentials: accountsCount > 0,
      };
    }
    return {
      success: false,
      elapsedMs,
      message: `billing 验证失败 · ${balance.error || "上游拒绝"}`,
      region: (cfg.region as string) || "cn",
      hasCredentials: accountsCount > 0,
      error: balance.error,
    };
  } catch (e) {
    return {
      success: false,
      elapsedMs: Date.now() - started,
      message: "billing 探活失败",
      error: networkErrorMessage(e),
      region: (cfg.region as string) || "cn",
    };
  }
}

async function fetchStandardModels(
  type: string,
  cfg: Record<string, unknown>,
  providerId: string,
  proxyOverride: string | null
): Promise<{ models: string[]; url: string }> {
  let url: string;
  let headers: Record<string, string> = { Accept: "application/json" };
  switch (type) {
    case "openai": {
      url = `${((cfg.baseUrl as string) || "https://api.openai.com/v1").replace(/\/$/, "")}/models`;
      headers = { ...headers, Authorization: `Bearer ${(cfg.apiKey as string) || ""}` };
      break;
    }
    case "anthropic": {
      url = `${((cfg.baseUrl as string) || "https://api.anthropic.com").replace(/\/$/, "")}/models`;
      headers = {
        ...headers,
        "x-api-key": (cfg.apiKey as string) || "",
        "anthropic-version": (cfg.anthropicVersion as string) || "2023-06-01",
      };
      break;
    }
    case "opencode": {
      url = `${((cfg.baseUrl as string) || "https://opencode.ai/zen/v1").replace(/\/$/, "")}/models`;
      headers = { ...headers, "User-Agent": "opencode/1.18.30", "x-opencode-client": "cli" };
      break;
    }
    default:
      throw new Error(`provider type "${type}" 无探活端点`);
  }
  const resp = await fetchWithProxy(
    url,
    { headers, signal: AbortSignal.timeout(TEST_TIMEOUT_MS) },
    { providerId, providerOverride: proxyOverride ?? undefined }
  );
  if (!resp.ok) throw new Error(`HTTP ${resp.status} · ${((await resp.text().catch(() => "")) || "").slice(0, 120)}`);
  const json = (await resp.json().catch(() => ({}))) as { data?: Array<{ id?: string }>; models?: Array<{ id?: string }> };
  const models = (json.data || json.models || []).map((m) => m.id).filter((x): x is string => !!x);
  return { models, url };
}

export async function POST(request: NextRequest) {
  const session = await requireSessionOr401(request);
  if (session instanceof Response) return session;

  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return ok({ success: false, elapsedMs: 0, message: "请求体不是合法 JSON" } satisfies ProviderTestResult);
  }

  const providerId = typeof body.providerId === "string" ? body.providerId : "";
  const type = typeof body.type === "string" ? body.type : "";

  try {
    // ---- 载荷 A：DB 已存提供商实测 ----
    if (providerId) {
      const provider = await db.provider.findUnique({ where: { id: providerId } });
      if (!provider) {
        return ok({ success: false, elapsedMs: 0, message: `提供商「${providerId}」不存在` } satisfies ProviderTestResult);
      }
      if (provider.type === "workbuddy") {
        const cfg = await buildWorkbuddyConfig(providerId);
        if (!cfg) return ok({ success: false, elapsedMs: 0, message: "提供商配置组装失败" } satisfies ProviderTestResult);
        return ok(await testWorkbuddy(providerId, cfg, provider.proxyOverride ?? null));
      }
      // openai / anthropic / opencode：上游 models 探活
      const started = Date.now();
      try {
        const { models, url } = await fetchStandardModels(
          provider.type,
          (provider.config as Record<string, unknown>) || {},
          providerId,
          provider.proxyOverride ?? null
        );
        return ok({
          success: true,
          elapsedMs: Date.now() - started,
          message: `models 接口连通 · ${models.length} 个模型`,
          modelsCount: models.length,
          models: models.slice(0, 50),
          hasCredentials: !!((provider.config as Record<string, unknown>)?.apiKey),
        } satisfies ProviderTestResult);
      } catch (e) {
        return ok({
          success: false,
          elapsedMs: Date.now() - started,
          message: "models 探活失败",
          error: networkErrorMessage(e),
        } satisfies ProviderTestResult);
      }
    }

    // ---- 载荷 B：草稿实测（表单值，未落库）----
    if (type === "workbuddy") {
      const config = (body.config as Record<string, unknown>) || {};
      const credentials = (body.credentials as Record<string, unknown>) || {};
      const draftAccount = {
        id: "__draft__",
        name: "草稿凭据",
        enabled: true,
        ...credentials,
      };
      return ok(
        await testWorkbuddy("__draft__", { ...config, accounts: [draftAccount] }, (config.proxyOverride as string) || null)
      );
    }
    if (type === "openai" || type === "anthropic" || type === "opencode") {
      const config = (body.config as Record<string, unknown>) || {};
      const credentials = (body.credentials as Record<string, unknown>) || {};
      const cfg = { ...config, ...credentials };
      const started = Date.now();
      try {
        const { models, url } = await fetchStandardModels(type, cfg, "__draft__", (config.proxyOverride as string) || null);
        return ok({
          success: true,
          elapsedMs: Date.now() - started,
          message: `models 接口连通 · ${models.length} 个模型`,
          modelsCount: models.length,
          models: models.slice(0, 50),
          hasCredentials: !!(cfg.apiKey || type === "opencode"),
        } satisfies ProviderTestResult);
      } catch (e) {
        return ok({
          success: false,
          elapsedMs: Date.now() - started,
          message: "models 探活失败",
          error: networkErrorMessage(e),
        } satisfies ProviderTestResult);
      }
    }
    if (type === "qwenweb") {
      const credentials = (body.credentials as Record<string, unknown>) || {};
      const hasToken = !!credentials.token;
      const hasCookie = !!credentials.cookie;
      return ok({
        success: hasToken && hasCookie,
        elapsedMs: 0,
        message: hasToken && hasCookie
          ? "凭据具备性校验通过 · qwenweb 反爬链需真实调用验证（无轻量探活端点）"
          : "凭据不完整 · 需要 token 与 cookie",
        hasCredentials: hasToken && hasCookie,
      } satisfies ProviderTestResult);
    }
    return ok({ success: false, elapsedMs: 0, message: `不支持的提供商类型「${type}」` } satisfies ProviderTestResult);
  } catch (e) {
    // 兜底：绝不 500
    return ok({
      success: false,
      elapsedMs: 0,
      message: "探活异常",
      error: networkErrorMessage(e),
    } satisfies ProviderTestResult);
  }
}
