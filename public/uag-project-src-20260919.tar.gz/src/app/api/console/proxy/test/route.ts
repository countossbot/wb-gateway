// POST /api/console/proxy/test —— 代理连通性实测（v3.6.0 修复：该端点此前不存在，
// 设置页「测试代理（按当前草稿）」按钮自创建起即 404 —— Task 26 巡检发现并修复）。
//
// 语义：
//   - body 携带草稿（proxyList/bypass）：实测「用户当前输入」而非已保存配置 ——
//     列表非空时逐地址并行实测（cap 5，掩码回显不泄凭据）；列表为空时测直连出口。
//     不落库配置（保存仍走 PUT /api/console/settings），仅追加测试历史。
//   - body 为空对象：按当前生效配置实测（提供商作用域等场景的历史行为）。
//
// 持久化：
//   - proxy.lastTest（运行时设置，总览可展示最近一次结果）
//   - proxyTestHistory（SystemSetting 键，JSON 数组，cap 20，设置页「测试历史」面板数据源）
//   GET 返回 { lastTest, history }；DELETE 清空历史（仅测试留痕，非业务数据）。
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { requireSessionOr401, ok } from "@/lib/gateway/console/consoleHelpers";
import { testProxy, parseProxyList, proxyDiagnostics } from "@/lib/gateway/proxy/proxyAgent";
import { saveRuntimeSetting, getRuntimeSettingsAsync } from "@/lib/gateway/config/runtimeSettings";

export const dynamic = "force-dynamic";

const HISTORY_KEY = "proxyTestHistory";
const HISTORY_CAP = 20;

interface ProxyTestRecord {
  ok: boolean;
  exitIp?: string;
  elapsedMs: number;
  error?: string;
  mode: "draft" | "direct" | "global";
  pool?: Array<{ masked: string; ok: boolean; elapsedMs: number; exitIp?: string; error?: string }>;
  at: string;
}

async function readHistory(): Promise<ProxyTestRecord[]> {
  try {
    const row = await db.systemSetting.findUnique({ where: { key: HISTORY_KEY } });
    const v = row?.value;
    return Array.isArray(v) ? (v as unknown as ProxyTestRecord[]) : [];
  } catch {
    return [];
  }
}

async function appendHistory(rec: ProxyTestRecord): Promise<ProxyTestRecord[]> {
  const history = [rec, ...(await readHistory())].slice(0, HISTORY_CAP);
  try {
    await db.systemSetting.upsert({
      where: { key: HISTORY_KEY },
      create: { key: HISTORY_KEY, value: history as never },
      update: { value: history as never },
    });
  } catch {
    /* 历史写失败不阻断测试结果返回 */
  }
  return history;
}

export async function GET(request: NextRequest) {
  const session = await requireSessionOr401(request);
  if (session instanceof Response) return session;
  const settings = await getRuntimeSettingsAsync();
  const history = await readHistory();
  return ok({
    lastTest: settings.proxy?.lastTest ?? null,
    history,
    diagnostics: proxyDiagnostics(),
  });
}

export async function POST(request: NextRequest) {
  const session = await requireSessionOr401(request);
  if (session instanceof Response) return session;

  const body = (await request.json().catch(() => ({}))) as {
    proxyList?: string | string[];
    bypass?: string[];
  };

  // 草稿列表兼容字符串（设置页 textarea）与数组两种形态
  const rawList = Array.isArray(body.proxyList) ? body.proxyList.join(",") : body.proxyList;
  const draftList = parseProxyList(rawList);
  // 草稿语义：显式传了 proxyList 字段（字符串或数组）即按草稿/直连路径实测；
  // 设置页始终传 textarea 字符串（空串=直连出口），只有服务端内部调用（无 body）才走生效配置
  const hasDraft = body.proxyList !== undefined && body.proxyList !== null;
  const bypass = Array.isArray(body.bypass) ? body.bypass.map((s) => String(s).trim()).filter(Boolean) : [];

  const result = await testProxy("https://api.ipify.org/?format=json", null, hasDraft ? { list: draftList, bypass } : null);
  const mode: ProxyTestRecord["mode"] = !hasDraft ? "global" : draftList.length > 0 ? "draft" : "direct";

  const rec: ProxyTestRecord = {
    ok: result.ok,
    exitIp: result.exitIp,
    elapsedMs: result.elapsedMs,
    error: result.error,
    mode,
    pool: result.pool,
    at: new Date().toISOString(),
  };

  // lastTest 写入运行时设置（热生效，总览/设置页「最近一次测试」消费）
  try {
    const settings = await getRuntimeSettingsAsync();
    const proxyConf = settings.proxy ? { ...settings.proxy } : { enabled: false, list: "", bypass: [] };
    proxyConf.lastTest = { ok: rec.ok, exitIp: rec.exitIp, elapsedMs: rec.elapsedMs, error: rec.error, at: rec.at };
    await saveRuntimeSetting("proxy", proxyConf);
  } catch {
    /* lastTest 写失败不阻断 */
  }

  const history = await appendHistory(rec);
  return ok({ ...rec, history });
}

export async function DELETE(request: NextRequest) {
  const session = await requireSessionOr401(request);
  if (session instanceof Response) return session;
  try {
    await db.systemSetting.deleteMany({ where: { key: HISTORY_KEY } });
  } catch {
    /* noop */
  }
  return ok({ history: [] });
}
